import TicketForm from "./TicketForm";

export default function Home() {
  return <TicketForm />;
}
